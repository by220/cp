function myready() {
	changeh(document.documentElement.scrollHeight + 500);
}