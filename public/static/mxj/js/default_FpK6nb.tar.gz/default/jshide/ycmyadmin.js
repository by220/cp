function myready(){

}