function myready() {
}