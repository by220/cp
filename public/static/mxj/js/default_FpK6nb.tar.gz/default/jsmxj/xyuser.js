// JavaScript Document
function myready(){
	$(document).keydown(function(event){ 
	      if(event.keyCode == 13){ 
                   $(".tongyi").click();
		  }

	});
}

